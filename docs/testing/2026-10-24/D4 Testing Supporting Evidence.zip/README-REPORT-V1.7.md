D4 testing report version 1.7, 24 October 2026. Prepared by Minh. All 41 pages use portrait orientation. All 26 table titles and body references are retained.
