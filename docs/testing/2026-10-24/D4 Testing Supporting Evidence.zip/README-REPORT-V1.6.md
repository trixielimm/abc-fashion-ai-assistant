# D4 testing report version 1.6

Prepared by Minh on 24 October 2026.

All 26 tables have numbered titles and linked body references in the form (see TABLE X). The document and PDF author metadata identify Minh. Test cases, outcomes and evidence links are unchanged.

The current editable report and PDF are in report/. Historical raw evidence is retained for traceability. The formatting audit and table inventory are in docs/test-evidence/d4-formatting-2026-10-24/.
